(function($){
	
	$(document).ready(function(){
		
		var galLink = $("a.gal_link");
		
		
		galLink.lightbox();
		
		

		
	});
	
})(jQuery);