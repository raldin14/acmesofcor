Simple SPA page for the Acme Software Corporation
instruction:
First land to the page:
user can look for a gif with a specific keyword
allowing them to save their favoites and and looked into their history of searches
but this will only available if they are loged in.